
#ifndef __APP_LORAWAN_H__
#define __APP_LORAWAN_H__

#ifdef __cplusplus
extern "C" {
#endif

void MX_LoRaWAN_Init(void);
void MX_LoRaWAN_Process(void);

#ifdef __cplusplus
}
#endif

#endif
